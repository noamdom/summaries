package fw_bottle;

import java.util.Arrays;

public class VertWeight2EdgeWeight {
	static int infinity = Integer.MAX_VALUE;
	public static int[][] vertArray2EdgeMat(int[] vertexWeight, boolean mb[][]){
		// matWEdges building (matrix of weights by edges)
		int n = mb.length;
		int [][]matWEdges = new int[mb.length][mb[0].length];
		for (int i = 0; i < n; i++) Arrays.fill(matWEdges[i], infinity);
		for (int i = 0; i <n; i++) {
			for (int j = 0; j < n; j++) {
				if (mb[i][j] && i!=j) matWEdges[i][j] = vertexWeight[i] + vertexWeight[j];
			}
		}
		System.out.println("\nweights of vertices");
		printMatrix(matWEdges);
		return matWEdges;
	}
	/** vertexWeight - array of vertexes weights
	 * @param vertexWeight array of vertexes weights
	 * @param mb   - matrix connections, if mb[i]]j] = true exists edge between vertices i, j
	                 if mb[i]]j] = false the edge between vertices i, j does not exists
	 */
	public static int[][] FWAlgorithm2VerWe(int[] vertexWeight, boolean mb[][]){
		//
		int[][] matWEdges = vertArray2EdgeMat(vertexWeight, mb);
		FWAlgorithm(matWEdges);
		return matWEdges;
	}
	public static void FWAlgorithm(int mat[][]){
		int n = mat.length;
		for (int k = 0; k<n; k++){
			for (int i = 0; i<n; i++){
				for (int j = 0; j<n; j++){
					if (mat[i][k]!=infinity && mat[k][j]!=infinity){
						if (mat[i][j] > mat[i][k]+mat[k][j]){
							mat[i][j] = mat[i][k]+mat[k][j];
						}
					}
				}
			}
		}
	}


	public static boolean checkNegativeCircle(int[][] mat){
		boolean ans = false;
		for (int i = 0; !ans && i<mat.length; i++){
			if (mat[i][i]<0) ans = true;
		}
		return ans;
	}
	/**
	 * @param vertexWeight array of vertices weights
	 * @param matWEdges matrix of edges weights
	 * @return matWVert - matrix of vertices weights
	 */
	public static int[][] edge2VertWeights(int[] vertexWeight, int matWEdges[][]){
		int n = matWEdges.length;
		int[][] matWVert = new int[n][n];
		for(int i=0; i<n; i++){
			for(int j=0; j<n; j++){
				if (matWEdges[i][j]!=infinity)
					matWVert[i][j] = (matWEdges[i][j] + vertexWeight[i] + vertexWeight[j])/2;
				else matWVert[i][j] = infinity;
			}
		}
		return matWVert;
	}
	/**
	 * @param vertexWeight - array of vertices weights
	 * @param matWVert matrix of edges weights
	 * @return - matrix of vertices weights
	 */
	public static int[][] ver2EdgeWeights(int[] vertexWeight, int matWVert[][]){
		int n = matWVert.length;
		int [][] matWEdges = new int[n][n];
		for(int i=0; i<n; i++){
			for(int j=0; j<n; j++){
				if (matWVert[i][j]!=infinity)
					matWEdges[i][j] = 2*matWVert[i][j] - vertexWeight[i] - vertexWeight[j];
			}
		}
		return matWEdges;
	}

	public static void checkFWVerToEdges(){
		boolean mb[][] = initB1();
		int [] weVert = {1,2,3,4};
		int[][] mat = FWAlgorithm2VerWe(weVert, mb);
		System.out.println("matrix of prices");
		printMatrix(mat);
		System.out.println("matrix of vertices weights");
		printMatrix(edge2VertWeights(weVert, mat));
		System.out.println("matrix of edges weights");
		printMatrix(ver2EdgeWeights(weVert, edge2VertWeights(weVert, mat)));
	}
	public static void printMatrix(int[][] mat){
		for(int i=0; i<mat.length; i++){
			for(int j=0; j<mat[0].length; j++){
				if (i==j) System.out.print("0, ");
				else if (mat[i][j] ==infinity) System.out.print("*, ");
				else System.out.print(mat[i][j]+", ");
			}
			System.out.println();
		}
	}
	public static boolean[][] initB1(){
		boolean [][] mat = {{true,true,true,false}, 
							{true,true,false,true},
							{true,false,true,true},
							{false,true,true,true}};

		return mat;	
	}
	public static boolean[][] initB2(){
		boolean [][] mat = {{true,false,false,false}, 
				{false,true,true,true},
				{false,true,true,true},
				{false,true,true,false}};
		return mat;	
	}
	public static void main(String[] args) {
		checkFWVerToEdges();

	}

}
