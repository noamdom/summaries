package euler;

import java.util.ArrayList;

public class InitGraphs {
	@SuppressWarnings("unchecked")
	public static ArrayList<Integer>[] init1(){//cycle: [0, 2, 4, 3, 2, 1, 0]
		int numVert = 5;
		ArrayList<Integer>[] graph = new ArrayList[numVert];
		for (int i=0; i<graph.length; i++){
			graph[i] = new ArrayList<Integer>();
		}
		graph[0].add(1); graph[0].add(2); 
		graph[1].add(0); graph[1].add(2); 
		graph[2].add(0); graph[2].add(1); graph[2].add(3); graph[2].add(4); 
		graph[3].add(2); graph[3].add(4); 
		graph[4].add(3); graph[4].add(2); 
		return graph;
	}
	@SuppressWarnings("unchecked")
	public static ArrayList<Integer>[] init2(){//pentagon, cycle: [0, 4, 3, 2, 4, 1, 3, 0, 2, 1, 0]
		int numVert = 5;
		ArrayList<Integer>[] graph = new ArrayList[numVert];
		for (int i=0; i<graph.length; i++){
			graph[i] = new ArrayList<Integer>();
		}
		graph[0].add(1); graph[0].add(2); graph[0].add(3); graph[0].add(4);
		graph[1].add(0); graph[1].add(2); graph[1].add(3); graph[1].add(4);
		graph[2].add(0); graph[2].add(1); graph[2].add(3); graph[2].add(4); 
		graph[3].add(0); graph[3].add(1); graph[3].add(2); graph[3].add(4);
		graph[4].add(0); graph[4].add(1); graph[4].add(2); graph[4].add(3); 
		return graph;
	}
	@SuppressWarnings("unchecked")
	public static ArrayList<Integer>[] init3(){// cycle: [0, 8, 7, 0, 6, 5, 0, 4, 3, 0, 2, 1, 0]
		int numVert = 9;
		ArrayList<Integer>[] graph = new ArrayList[numVert];
		for (int i=0; i<graph.length; i++){
			graph[i] = new ArrayList<Integer>();
		}
		graph[0].add(1); graph[0].add(2); graph[0].add(3); graph[0].add(4);
		graph[0].add(5); graph[0].add(6);graph[0].add(7); graph[0].add(8);

		graph[1].add(0); graph[1].add(2); 
		graph[2].add(0); graph[2].add(1); 
		graph[3].add(0); graph[3].add(4); 
		graph[4].add(0); graph[4].add(3); 
		graph[5].add(0); graph[5].add(6); 
		graph[6].add(0); graph[6].add(5); 
		graph[7].add(0); graph[7].add(8); 
		graph[8].add(0); graph[8].add(7); 

		return graph;
	}
	@SuppressWarnings("unchecked")
	public static ArrayList<Integer>[] init4(){//has no Euler Cycle
		int numVert = 4;
		ArrayList<Integer>[] graph = new ArrayList[numVert];
		for (int i=0; i<graph.length; i++){
			graph[i] = new ArrayList<Integer>();
		}
		graph[0].add(1); graph[0].add(2); graph[0].add(3);
		graph[1].add(0); graph[1].add(2); graph[1].add(3);
		graph[2].add(1); graph[2].add(0); graph[2].add(3);
		graph[3].add(1); graph[3].add(2); graph[3].add(0);
		return graph;
	}
	@SuppressWarnings("unchecked")
	public static ArrayList<Integer>[] init5(){//square ,the cycle: [0, 3, 2, 1, 0]
		int size = 4;
		ArrayList<Integer>[] graph = new ArrayList[size];
		for (int i=0; i<size; i++){
			graph[i] = new ArrayList<Integer>();
		}
		graph[0].add(1); graph[0].add(3);
		graph[1].add(0); graph[1].add(2);
		graph[2].add(1); graph[2].add(3);
		graph[3].add(0); graph[3].add(2);
		return graph;
	}
	public static ArrayList<Integer>[] init6(){//the cycle: [0, 4, 5, 3, 4, 2, 3, 0, 2, 1, 0]
		int size = 6;
		ArrayList<Integer>[] graph = new ArrayList[size];
		for (int i=0; i<size; i++){
			graph[i] = new ArrayList<Integer>();
		}
		graph[0].add(1); graph[0].add(2);graph[0].add(3); graph[0].add(4);
		graph[1].add(0); graph[1].add(2);
		graph[2].add(0); graph[2].add(1);graph[2].add(3); graph[2].add(4);
		graph[3].add(0); graph[3].add(2);graph[3].add(4); graph[3].add(5);
		graph[4].add(0); graph[4].add(2);graph[4].add(3); graph[4].add(5);
		graph[5].add(3); graph[5].add(4);
		return graph;
	}
	public static ArrayList<Integer>[] init7(){//triangle, the cycle:[0, 2, 1, 0]
		int size = 3;
		ArrayList<Integer>[] graph = new ArrayList[size];
		for (int i=0; i<size; i++){
			graph[i] = new ArrayList<Integer>();
		}
		graph[0].add(1); graph[0].add(2);
		graph[1].add(0); graph[1].add(2);
		graph[2].add(0); graph[2].add(1);
		return graph;
	}
}
